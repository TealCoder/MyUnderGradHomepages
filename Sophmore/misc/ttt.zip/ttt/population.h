#ifndef POPULATION
#define POPULATION

#include "individual.h"
#include "tester.h"
class population
{
public:
	population(int s);
	individual evolve(int gens);
	void printbest();
private:
	int size;
	int age;

	vector <individual*> pop;
	tester thetester;

	void midsort();
	void swap(int a, int b);
};

population::population(int s)
{
	age = 0;
	size = s;
	individual * address;
	while (size % 4 != 0 || size < 4) size++;
	cout << "*** Creating a new population of size " << size << " ***" << endl;
	for (int i = 0; i < size; i++)
	{
		address = new individual();
		address->setfitness(thetester.test(*address));
		pop.push_back(address);
	}
}

individual population::evolve(int gens)
{
	int i, j;
	individual* address;
	for (i = 0; i < gens; i++) {
		printbest();
		age++;
		for (j = 0; j < size / 2; j++)
			pop.pop_back();
		for (j = 0; j < size / 2; j++)
		{
			address = pop[size / 2 - j - 1]->breed(*(pop[size / 2]));
			address->setfitness(thetester.test(*address));
			pop.push_back(address);
		}
	}
	printbest();
		return *pop[0];
}
void population::printbest()
{
	midsort();
	int bob = pop.size() / 2;
	while (bob > 0)
	{
		if (pop[bob]->getfitness() > pop[0]->getfitness())
			swap(bob, 0);
		bob--;
	}
	cout << "*** Best of generation " << age << " ***" << endl;
	pop[0]->print();
}

void population::midsort()
{
	int low = 0;
	int high = size - 1;
	int scanup;
	int scandown;
	double pivot;
	int mid;
	while (low < high)
	{
		mid = low + (high - low) / 2;
		swap(mid, low);
		pivot = pop[low]->getfitness();
		scanup = low;
		scandown = high;

		while (true)
		{
			while ((pop[++scanup]->getfitness()) > pivot && (scanup < scandown));
			while ((pop[scandown]->getfitness()) < pivot && (scanup < scandown)) scandown--;
			if (scanup < scandown)
				swap(scanup, scandown);
			else break;
		}
		swap(scanup - 1, low);
		if ((size - 1) / 2 > scanup) low = scanup + 1;
		if ((size - 1) / 2 < scanup) high = scanup - 1;
		if ((size - 1) / 2 == scanup) low = high;
	}
}

void population::swap(int a, int b)
{
	individual* hold = pop[a];
	pop[a] = pop[b];
	pop[b] = hold;
}

#endif