#ifndef FUNC
#define FUNC
	const static double (func[18])();
	func[0]() { return 1.0; };
	func[1]() { return 1.0; };
	func[2]() { return 1.0; };
	func[3]() { return 1.0; };
	func[4]() { return 1.0; };
	func[5]() { return 1.0; };
	func[6]() { return 1.0; };
	func[7]() { return 1.0; };
	func[8]() { return 1.0; };
	func[9]() { return 1.0; };
	func[10]() { return 1.0; };
	func[11]() { return 1.0; };
	func[12]() { return 1.0; };
	func[13]() { return 1.0; };
	func[14]() { return 1.0; };
	func[15]() { return 1.0; };
	func[16]() { return 1.0; };
	func[17]() { return 1.0; };
	//9 0 1 2 3 4 5 6 7
	//0 1 + - * / = > < 
#endif