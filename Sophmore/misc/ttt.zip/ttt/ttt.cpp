//All original code

#include <iostream>
#include <cmath>
#include <ctime>
using namespace std;

#include "game.h"

int main() {
	srand(time(0));
	/*
	cout << "Choose Players:" << endl;
	cout << "0: Human" << "\n1: Computer Recursion"
		<< "\n2: Evolutionary Algorythm" << endl;
	cout << "\nEnter choice for Xs." << endl;
	int p1; cin >> p1;
	cout << "\nEnter choice for Os." << endl;
	int p2; cin >> p2;
	//*/
	int p1=1, p2 = 2;
	game g(p1, p2);
	g.play();
	//*/

	/*
	population newpop(100);
	newpop.evolve(5);
	int i; cin >> i;
	//*/

	/*
	queue<int> q;
	q.push(1);
	individual a = individual(q,q,q);
	a.print();
	individual b = individual(q,q,q);
	b.print();
	individual c = a.breed(b);
	c.print();
	int i; cin >> i;
	//*/

	return 0;
}

