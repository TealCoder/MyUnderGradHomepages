#ifndef TTT
#define TTT

#include "population.h"

class game
{
public:
	game(int i, int j) { players[0] = i; players[1] = j; evolved = false; };
	void play();
private:
	void newgame(int i, int j) { players[0] = i; players[1] = j;};
	bool win(bool XorO);
	void printboard();
	int human();
	char space(int whodere);
	int comp(bool Xor);
	int comp2(bool XorO);
	bool move(bool XorO, int player);
	int recursion(bool XorO);
	int board[3][3];
	int players[2];
	individual ind;
	bool evolved;
};

void game::play()
{
	int i;
	for (i = 0; i < 9; i++)
		board[i/3][i%3] = 0;

	for (i = 0; i < 1; i++);
		if (players[i] > 2 || players < 0) players[i] = 0;

	bool XorO = false;
	i = 0;
	while (++i < 10 && !move(XorO, (XorO?players[1]:players[0])) ) XorO = !XorO;

	printboard();
	if (i == 10) cout << "Cats Game." << endl;
	else {
		if (XorO) cout << "O Wins." << endl;
		else cout << "X Wins." << endl;
	}
	cin.ignore();
	cout << "Press 'Enter' to continue.\n";
	cin.peek();
}

bool game::move(bool XorO, int player)
{
	int move = 5;
	if (player == 0) move = human();
	else
	{
		if (player == 1) move = comp(XorO);
		else move = comp2(XorO);
	}

	printboard();
	if (XorO) board[move/3][move%3] = 1;
	else board[move/3][move%3] = -1;

	return win(XorO);
}

int game::human()
{
	int move = -3325655, i;
	while (move < 0 || move > 8 || board[move/3][move%3] != 0)
	{
		if (move != -3325655) cout << "That is not a legal move.\n" << endl;
		printboard();
		cout << "Enter column: ";
		cin >> move;
		cout << "Enter row: ";
		cin >> i;
		move += 3 * i - 4;
	}
	return move;
}


bool game::win(bool XorO)
{
	int win = -3;
	if (XorO) win = 3;
	if (board[0][0] + board[0][1] + board[0][2] == win) return true;
	if (board[1][0] + board[1][1] + board[1][2] == win) return true;
	if (board[2][0] + board[2][1] + board[2][2] == win) return true;
	if (board[0][0] + board[1][0] + board[2][0] == win) return true;
	if (board[0][1] + board[1][1] + board[2][1] == win) return true;
	if (board[0][2] + board[1][2] + board[2][2] == win) return true;
	if (board[0][0] + board[1][1] + board[2][2] == win) return true;
	if (board[2][0] + board[1][1] + board[0][2] == win) return true;
	return false;
}

void game::printboard()
{
	cout << space(board[0][0]) << "|" << space(board[0][1]) << "|" << space(board[0][2]);
	cout << "\n-+-+-\n";
	cout << space(board[1][0]) << "|" << space(board[1][1]) << "|" << space(board[1][2]);
	cout << "\n-+-+-\n";
	cout << space(board[2][0]) << "|" << space(board[2][1]) << "|" << space(board[2][2]);
	cout << endl << endl;
}

char game::space(int whodere)
{
	switch (whodere)
	{
	case -1: return 'X';
	case 0: return ' ';
	case 1: return 'O';
	}
	return '?';
}

int game::comp(bool XorO)
{
	int bestval = -1000;
	int bestmove = 0;
	int moveval;
	for (int move = 0; move < 9; move++)
	{
		if (board[move/3][move%3] == 0)
		{
			board[move/3][move%3] = XorO?1:-1;
			if (win(XorO)) moveval = 100;
			else moveval = -recursion(!XorO);
			if (moveval > bestval || (moveval == bestval && rand()%7 == 0) )
			{
				bestmove = move;
				bestval = moveval;
			}
			board[move/3][move%3] = 0;
		}
	}
	return bestmove;
}

int game::recursion(bool XorO)
{
	int bestval = -100;
	int moveval = 0;
	for (int move = 0; move < 9; move++)
	{
		if (board[move/3][move%3] == 0)
		{
			board[move/3][move%3] = XorO?1:-1;
			if (win(XorO)) moveval = 1;
			else moveval = -recursion(!XorO);
			if (moveval > bestval) bestval = moveval;
			board[move/3][move%3] = 0;
		}
	}
	if (bestval == -100) return 0;
	return bestval;
}

int game::comp2(bool XorO) {
	if (!evolved)
	{
		population thepop(100000);
		ind = (thepop.evolve(10));
		evolved = true;
	}
	return 	ind.evaluate(XorO, board);

}

#endif