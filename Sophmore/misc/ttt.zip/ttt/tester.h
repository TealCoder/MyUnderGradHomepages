#ifndef TESTER
#define TESTER

class tester
{
public:
	tester() {};
	double test(individual& ind);
private:
	int board[3][3];
	double nextmove(bool XorO, int turn, individual& ind);
	bool win(bool XorO);
};

double tester::test(individual& ind)
{
	double fitness = 0;

	for (int i = 0; i < 9; i++)
		board[i/3][i%3] = 0;

	fitness += nextmove(true, 0, ind);
	fitness += nextmove(false, 0, ind);

	return fitness;
}

double tester::nextmove(bool XorO, int turn, individual& ind)
{
	int move;
	double localfitness = 0;

	if (turn == 9)
		return 0;
	if ((turn%2==0 && XorO) || (turn%2==1 && !XorO))
	{
		move = ind.evaluate(XorO, board);
		board[move/3][move%3] = (XorO?1:-1);
		if (win(XorO)) localfitness = 1;
		else localfitness += nextmove(XorO, turn + 1, ind);
		board[move/3][move%3] = 0;
	}
	else
	{
		for (move = 0; move < 9; move++)
		{
			if (board[move/3][move%3] == 0)
			{
				board[move/3][move%3] = (XorO?1:-1);
				if (win(XorO)) localfitness -= 1;
				else localfitness -= nextmove(XorO, turn + 1, ind);
				board[move/3][move%3] = 0;
			}
		}
	}
	return localfitness/2;
}
bool tester::win(bool XorO)
{
	int win = -3;
	if (XorO) win = 3;
	if (board[0][0] + board[0][1] + board[0][2] == win) return true;
	if (board[1][0] + board[1][1] + board[1][2] == win) return true;
	if (board[2][0] + board[2][1] + board[2][2] == win) return true;
	if (board[0][0] + board[1][0] + board[2][0] == win) return true;
	if (board[0][1] + board[1][1] + board[2][1] == win) return true;
	if (board[0][2] + board[1][2] + board[2][2] == win) return true;
	if (board[0][0] + board[1][1] + board[2][2] == win) return true;
	if (board[2][0] + board[1][1] + board[0][2] == win) return true;
	return false;
}
//*/
#endif