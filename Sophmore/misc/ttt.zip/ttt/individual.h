#ifndef INDIVIDUAL
#define INDIVIDUAL

#include <string>
#include <queue>

class individual
{
public:
	individual();
	individual(queue<int> new_corner, queue<int> new_middle, queue<int> new_center);
	double getfitness() { return _fitness; }
	void setfitness(double fit) { _fitness = fit; }
	int evaluate(bool XorO, int playboard[3][3]);
	void print();
	individual* operator= (const individual& rhs);
	individual* breed(individual& mate);
private:
	queue<int> mix(queue<int> q1, queue<int> q2);
	double func();
	void printfunc();
	void rotateboard();
	queue<int> random_expression(int maxlength);

	double _fitness;
	queue<int> _corner;
	queue<int> _middle;
	queue<int> _center;
	queue<int> _exp;
	int _board[3][3];
};

individual::individual()
{
	_corner = random_expression(50);
	_middle = random_expression(50);
	_center = random_expression(50);
}

individual * individual::breed(individual& mate)
{
	queue<int> c, m, e;
	this->_exp = this->_corner;
	mate._exp = mate._corner;
	c = mix(this->_exp, mate._exp);
	this->_exp = this->_middle;
	mate._exp = mate._middle;
	m = mix(this->_exp, mate._exp);
	this->_exp = this->_center;
	mate._exp = mate._center;
	e = mix(this->_exp, mate._exp);
	return new individual(c, m, e);
};

queue<int> individual::mix(queue<int> q1, queue<int> q2)
{
	queue<int> q3;
	int swap1 = rand() % q1.size();
	int swap2 = rand() % q2.size();
	int i, arity;

	for (i = 0; i < swap1; i++)
	{
		q3.push(q1.front());
		q1.pop();
	}
	for (i = 0; i < swap2; i++)
		q2.pop();

	arity = 1;
	while (arity > 0)
	{
		q3.push(q2.front());
		if (q2.front() < 11) arity--;
		else
		{
			if (q2.front() < 15) arity++;
			else arity += 3;
		}
		q2.pop();
	}
	arity = 1;
	while (arity > 0 && !q1.empty())
	{
		if (q1.front() < 11) arity--;
		else
		{
			if (q1.front() < 15) arity++;
			else arity += 3;
		}
		q1.pop();
	}

	while (!q1.empty())
	{
		q3.push(q1.front());
		q1.pop();
	}
	return q3;
}

individual::individual(queue<int> new_corner, queue<int> new_middle, queue<int> new_center)
{
	_corner = new_corner;
	_middle = new_middle;
	_center = new_center;
}

int individual::evaluate(bool XorO, int playboard[3][3])
{
	int bestmove = 0, rotatecount = 0;
	double bestmoveval = -9999, moveval;
	bool testedmove;
	for (int i = 0; i < 9; i++)
	{
		if (XorO) _board[i/3][i%3] = playboard[i/3][i%3];
		else _board[i/3][i%3] = -playboard[i/3][i%3];
	}
	for (int move = 0; move < 9; move++)
	{
		if (_board[move/3][move%3] == 0)
		{
			testedmove = false;
			while (testedmove == false)
			{
				switch (move)
				{
				case 0:
					_exp = _corner;
					testedmove = true;
					break;
				case 1:
					_exp = _middle;
					testedmove = true;
					break;
				case 4:
					_exp = _center;
					testedmove = true;
					break;
				default:
					rotatecount++;
					rotateboard();
					move = (13 * ++move) % 10;
					move--;
				}
			}
			while (rotatecount%4 > 0)
			{
				rotateboard();
				move = (13 * ++move) % 10;
				move--;
				rotatecount++;
			}
			moveval = func();
			if (moveval > bestmoveval)
			{
				bestmoveval = moveval;
				bestmove = move;
			}
		}
	}
	return bestmove;
}

void individual::rotateboard()
{
	int hold = _board[0][0];
	_board[0][0] = _board[2][0];
	_board[2][0] = _board[2][2];
	_board[2][2] = _board[0][2];
	_board[0][2] = hold;

	hold = _board[1][0];
	_board[1][0] = _board[2][1];
	_board[2][1] = _board[1][2];
	_board[1][2] = _board[0][1];
	_board[0][1] = hold;
}

individual* individual::operator= (const individual& rhs)
{
	_corner = rhs._corner;
	_middle = rhs._middle;
	_center = rhs._center;
	_fitness = rhs._fitness;

	return this;
}

queue<int> individual::random_expression(int maxlength)
{
	queue<int> rand_exp;
	int arity = 1;
	int func;
	int curlength =0;
	int funcarity;
	while (arity > 0)
	{
		do
		{
			switch(rand()%4)
			{
				case 0:
					func = rand() % 9;
					funcarity = 0;
					break;
				case 1:
					func = 9 + rand() % 2;
					funcarity = 0;
					break;
				case 2:
					func = 11 +rand() % 4;
					funcarity = 2;
					break;
				case 3:
					func = 15 + rand() % 3;
					funcarity = 4;
					break;
			}
		} while (curlength + arity + funcarity-- > maxlength);

		arity += funcarity;
		curlength++;
		rand_exp.push(func);
	}
	return rand_exp;
}

double individual::func() {
	if (_exp.empty())
		return -1;
	int i = _exp.front();
	double a, b;
	_exp.pop();
	switch (i) {
	case 9:
		return 0;
	case 10:
		return 1;
	case 11:
		return func() + func();
	case 12:
		return func() - func();
	case 13:
		return func() * func();
	case 14:
		a = func();
		b = func();
		if (b == 0) return 10;
		else return a / b;
	case 15:
		if (func() != func()) _exp.pop();
		return func();
	case 16:
		if (func() <= func()) _exp.pop();
		return func();
	case 17:
		if (func() >= func()) _exp.pop();
		return func();
	case 18:
	default:
		return _board[i/3][i%3];
	}
}

void individual::print() {
	cout << "Fitness = " << _fitness << endl;
	cout << "Top Left Corner = ";
	_exp = _corner;
	printfunc();
	cout << "\nTop Middle = ";
	_exp = _middle;
	printfunc();
	cout << "\nCenter = ";
	_exp = _center;
	printfunc();
	cout << endl;
}

void individual::printfunc() {
	if (_exp.empty())
	{
		cout << "-1";
		return;
	}
	int i = _exp.front();
	_exp.pop();
	switch (i) {
	case 9:
		cout << "0";
		break;
	case 10:
		cout << "1";
		break;
	case 11:
		cout << "(";
		printfunc();
		cout << "+";
		printfunc();
		cout << ")";
		break;
	case 12:
		cout << "(";
		printfunc();
		cout << "-";
		printfunc();
		cout << ")";
		break;
	case 13:
		printfunc();
		cout << "*";
		printfunc();
		break;
	case 14:
		printfunc();
		cout << "/";
		printfunc();
		break;
	case 15:
		cout << "(";
		printfunc();
		cout << "==";
		printfunc();
		cout << "?";
		printfunc();
		cout << ":";
		printfunc();
		cout << ")";
		break;
	case 16:
		cout << "(";
		printfunc();
		cout << ">";
		printfunc();
		cout << "?";
		printfunc();
		cout << ":";
		printfunc();
		cout << ")";
		break;
	case 17:
		cout << "(";
		printfunc();
		cout << "<";
		printfunc();
		cout << "?";
		printfunc();
		cout << ":";
		printfunc();
		cout << ")";
		break;
	case 18:
	default:
		cout << "_board[" << i/3 << ", " << i%3 << "]";
	}
}

#endif